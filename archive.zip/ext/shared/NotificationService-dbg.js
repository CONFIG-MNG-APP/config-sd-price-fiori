/**
 * NotificationService — polls ZC_CONF_REQ_H for status changes and
 * surfaces them as in-app notifications (bell icon + popover).
 *
 * Usage:
 *   NotificationService.init(sSapClient);   // start polling
 *   NotificationService.getModel();         // JSONModel bound to bell
 *   NotificationService.markAllRead();
 *   NotificationService.destroy();          // stop polling on exit
 */
sap.ui.define(
  ["sap/ui/model/json/JSONModel"],
  function (JSONModel) {
    "use strict";

    var STORAGE_KEY  = "confmng_notif_seen";   // localStorage key
    var POLL_MS      = 60000;                  // poll every 60 s
    var SERVICE_URL  = "/sap/opu/odata4/sap/zui_conf_req/srvd/sap/zsd_conf_req/0001/";

    var STATUS_LABEL = {
      DRAFT:       "Draft",
      SUBMITTED:   "Submitted",
      APPROVED:    "Approved",
      REJECTED:    "Rejected",
      ROLLED_BACK: "Rolled Back",
      ACTIVE:      "Active",
      DEPLOYED:    "Deployed",
    };

    // ── private state ────────────────────────────────────────────────────
    var _oModel      = null;   // JSONModel exposed to views
    var _iTimer      = null;   // setInterval handle
    var _sSapClient  = "324";
    var _mSeen       = {};     // { ReqId: lastSeenStatus }

    // ── helpers ──────────────────────────────────────────────────────────
    function _loadSeen() {
      try {
        _mSeen = JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}");
      } catch (e) {
        _mSeen = {};
      }
    }

    function _saveSeen() {
      try { localStorage.setItem(STORAGE_KEY, JSON.stringify(_mSeen)); } catch (e) {}
    }

    function _formatTime(sIso) {
      if (!sIso) return "";
      try {
        var d = new Date(sIso);
        return d.toLocaleString("en-US", {
          month: "short", day: "numeric",
          hour: "2-digit", minute: "2-digit",
        });
      } catch (e) { return sIso; }
    }

    function _stateForStatus(sStatus) {
      if (sStatus === "APPROVED" || sStatus === "ACTIVE" || sStatus === "DEPLOYED") return "Success";
      if (sStatus === "REJECTED" || sStatus === "ROLLED_BACK") return "Error";
      if (sStatus === "SUBMITTED") return "Warning";
      return "None";
    }

    function _iconForStatus(sStatus) {
      var m = {
        APPROVED:    "sap-icon://accept",
        REJECTED:    "sap-icon://decline",
        SUBMITTED:   "sap-icon://pending",
        ACTIVE:      "sap-icon://sys-enter-2",
        DEPLOYED:    "sap-icon://upload",
        ROLLED_BACK: "sap-icon://undo",
        DRAFT:       "sap-icon://edit",
      };
      return m[sStatus] || "sap-icon://bell";
    }

    // ── core poll ────────────────────────────────────────────────────────
    function _poll() {
      var sUrl = SERVICE_URL +
        "ZC_CONF_REQ_H?$select=ReqId,ReqTitle,ModuleId,Status,ChangedAt" +
        "&$orderby=ChangedAt desc&$top=100" +
        "&sap-client=" + _sSapClient;

      fetch(sUrl, {
        credentials: "include",
        headers: { Accept: "application/json", "X-Requested-With": "XMLHttpRequest" },
      })
        .then(function (r) { return r.ok ? r.json() : Promise.reject(r.status); })
        .then(function (data) {
          var aItems = data.value || [];
          var aNotifs = _oModel.getProperty("/notifications") || [];
          var bChanged = false;

          aItems.forEach(function (oReq) {
            var sPrev = _mSeen[oReq.ReqId];
            // First time seeing this request — just record it, no notification
            if (sPrev === undefined) {
              _mSeen[oReq.ReqId] = oReq.Status;
              bChanged = true;
              return;
            }
            // Status changed → create notification
            if (sPrev !== oReq.Status) {
              var sLabel = STATUS_LABEL[oReq.Status] || oReq.Status;
              var sPrevLabel = STATUS_LABEL[sPrev] || sPrev;
              aNotifs.unshift({
                id:        oReq.ReqId + "_" + oReq.Status + "_" + Date.now(),
                ReqId:     oReq.ReqId,
                title:     oReq.ReqTitle || oReq.ReqId,
                message:   "Status changed: " + sPrevLabel + " → " + sLabel,
                status:    oReq.Status,
                statusLabel: sLabel,
                state:     _stateForStatus(oReq.Status),
                icon:      _iconForStatus(oReq.Status),
                time:      _formatTime(oReq.ChangedAt),
                read:      false,
              });
              _mSeen[oReq.ReqId] = oReq.Status;
              bChanged = true;
            }
          });

          if (bChanged) {
            // Keep max 50 notifications
            if (aNotifs.length > 50) { aNotifs = aNotifs.slice(0, 50); }
            _oModel.setProperty("/notifications", aNotifs);
            _oModel.setProperty("/unreadCount", aNotifs.filter(function (n) { return !n.read; }).length);
            _saveSeen();
          }
        })
        .catch(function (e) { console.warn("[NotificationService] poll error:", e); });
    }

    // ── public API ───────────────────────────────────────────────────────
    return {
      /**
       * Initialize the service. Call once from Dashboard onInit.
       * @param {string} sSapClient  e.g. "324"
       */
      init: function (sSapClient) {
        if (_oModel) return _oModel;   // already running

        _sSapClient = sSapClient || "324";
        _loadSeen();

        _oModel = new JSONModel({
          notifications: [],
          unreadCount:   0,
          panelOpen:     false,
        });

        // First poll immediately, then on interval
        _poll();
        _iTimer = setInterval(_poll, POLL_MS);

        return _oModel;
      },

      /** Returns the shared JSONModel (must call init first). */
      getModel: function () { return _oModel; },

      /** Mark all notifications as read. */
      markAllRead: function () {
        if (!_oModel) return;
        var aNotifs = _oModel.getProperty("/notifications") || [];
        aNotifs.forEach(function (n) { n.read = true; });
        _oModel.setProperty("/notifications", aNotifs);
        _oModel.setProperty("/unreadCount", 0);
      },

      /** Mark a single notification as read by id. */
      markRead: function (sId) {
        if (!_oModel) return;
        var aNotifs = _oModel.getProperty("/notifications") || [];
        var oN = aNotifs.find(function (n) { return n.id === sId; });
        if (oN && !oN.read) {
          oN.read = true;
          _oModel.setProperty("/notifications", aNotifs);
          _oModel.setProperty("/unreadCount",
            aNotifs.filter(function (n) { return !n.read; }).length);
        }
      },

      /** Clear all notifications. */
      clearAll: function () {
        if (!_oModel) return;
        _oModel.setProperty("/notifications", []);
        _oModel.setProperty("/unreadCount", 0);
      },

      /** Stop polling (call on view exit). */
      destroy: function () {
        if (_iTimer) { clearInterval(_iTimer); _iTimer = null; }
      },
    };
  }
);
