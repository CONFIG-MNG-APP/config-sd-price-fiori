sap.ui.define(
  [
    "zgsp26/conf/mng/sdprice/confmngfesdprice/ext/shared/ConfMngBaseController",
    "zgsp26/conf/mng/sdprice/confmngfesdprice/ext/shared/ExcelImport",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/SelectDialog",
    "sap/m/StandardListItem",
  ],
  function (
    BaseController,
    ExcelImport,
    MessageToast,
    MessageBox,
    JSONModel,
    Filter,
    FilterOperator,
    SelectDialog,
    StandardListItem
  ) {
    "use strict";

    return BaseController.extend(
      "zgsp26.conf.mng.sdprice.confmngfesdprice.ext.main.Main",
      {
        // ── Abstract overrides ────────────────────────────────────────────
        _getModuleId:  function () { return "SD"; },
        _getConfName:  function () { return "SD Price Configuration"; },
        _getTargetCds: function () { return "ZI_SD_PRICE_CONF"; },

        // ── Excel import config (SD Price specific) ───────────────────────
        _getExcelImportConfig: function () {
          return {
            headerMap: {
              "branch":          "BranchId",
              "branchid":        "BranchId",
              "branch_id":       "BranchId",
              "branch id":       "BranchId",
              "custgroup":       "CustGroup",
              "cust group":      "CustGroup",
              "cust_group":      "CustGroup",
              "customer group":  "CustGroup",
              "materialgrp":     "MaterialGrp",
              "material grp":    "MaterialGrp",
              "material_grp":    "MaterialGrp",
              "material group":  "MaterialGrp",
              "maxdiscount":     "MaxDiscount",
              "max discount":    "MaxDiscount",
              "max_discount":    "MaxDiscount",
              "discount":        "MaxDiscount",
              "minorderval":     "MinOrderVal",
              "min order val":   "MinOrderVal",
              "min_order_val":   "MinOrderVal",
              "min order value": "MinOrderVal",
              "approvergrp":     "ApproverGrp",
              "approver grp":    "ApproverGrp",
              "approver_grp":    "ApproverGrp",
              "approver":        "ApproverGrp",
              "currency":        "Currency",
              "validfrom":       "ValidFrom",
              "valid from":      "ValidFrom",
              "valid_from":      "ValidFrom",
              "from":            "ValidFrom",
              "validto":         "ValidTo",
              "valid to":        "ValidTo",
              "valid_to":        "ValidTo",
              "to":              "ValidTo",
              "changenote":      "ChangeNote",
              "change note":     "ChangeNote",
              "change_note":     "ChangeNote",
              "note":            "ChangeNote",
            },
            boolFields: [],
            buildRow: function (sEnvId) {
              return {
                ItemId:      "",
                EnvId:       sEnvId || "DEV",
                BranchId:    "",
                CustGroup:   "",
                MaterialGrp: "",
                MaxDiscount: 0,
                MinOrderVal: 0,
                ApproverGrp: "",
                Currency:    "",
                ValidFrom:   null,
                ValidTo:     null,
                VersionNo:   0,
                ChangeNote:  "",
                ActionType:  "C",
                _state:      "new",
                _reqItemId:  null,
              };
            },
          };
        },

        // ── Excel import methods ──────────────────────────────────────────

        _xlsxPromise: null,

        _ensureXlsxLoaded: function () {
          if (window.XLSX) return Promise.resolve();
          if (this._xlsxPromise) return this._xlsxPromise;

          var sPath = sap.ui.require.toUrl(
            "zgsp26/conf/mng/sdprice/confmngfesdprice/lib/xlsx.min"
          ) + ".js";

          this._xlsxPromise = new Promise(function (resolve, reject) {
            var oScript = document.createElement("script");
            oScript.src = sPath;
            oScript.onload = resolve;
            oScript.onerror = function () {
              reject(new Error("Failed to load SheetJS library"));
            };
            document.head.appendChild(oScript);
          });
          return this._xlsxPromise;
        },

        onImportFromExcel: function () {
          var that = this;
          var sReqId = this.getView().getModel("request").getProperty("/ReqId");
          if (!sReqId) {
            MessageBox.warning("Please create a request first before importing.");
            return;
          }

          this._ensureXlsxLoaded().then(function () {
            var oInput = document.createElement("input");
            oInput.type = "file";
            oInput.accept = ".xls,.xlsx,.csv";
            oInput.style.display = "none";
            document.body.appendChild(oInput);

            oInput.addEventListener("change", function (oEvent) {
              var oFile = oEvent.target.files[0];
              if (!oFile) { document.body.removeChild(oInput); return; }

              var oReader = new FileReader();
              oReader.onload = function (e) {
                try {
                  that._processExcelData(e.target.result);
                } catch (err) {
                  MessageBox.error("Could not read the Excel file: " + err.message);
                }
                document.body.removeChild(oInput);
              };
              oReader.onerror = function () {
                MessageBox.error("Failed to read file.");
                document.body.removeChild(oInput);
              };
              oReader.readAsArrayBuffer(oFile);
            });

            oInput.click();
          }).catch(function (err) {
            MessageBox.error("Failed to load Excel library: " + err.message);
          });
        },

        _processExcelData: function (arrayBuffer) {
          var workbook = XLSX.read(arrayBuffer, { type: "array" });
          var sEnvId   = this.getView().getModel("requestContext").getProperty("/EnvId") || "DEV";
          var result   = ExcelImport.parseWorkbook(workbook, sEnvId, this._getExcelImportConfig());

          if (result.errors.length && !result.rows.length) {
            MessageBox.error(result.errors.join("\n"));
            return;
          }

          if (result.rows.length > 500) {
            var that = this;
            MessageBox.confirm(
              "The file contains " + result.rows.length + " rows. This may take a moment. Continue?",
              {
                onClose: function (sAction) {
                  if (sAction === "OK") { that._insertImportedRows(result); }
                }
              }
            );
            return;
          }

          this._insertImportedRows(result);
        },

        _insertImportedRows: function (result) {
          var oTableModel = this.getView().getModel("tableData");
          var aRows       = oTableModel.getProperty("/rows");

          for (var i = result.rows.length - 1; i >= 0; i--) {
            aRows.unshift(result.rows[i]);
          }
          oTableModel.setProperty("/rows", aRows);
          this._applyBaseFilter();

          var sMsg = result.rows.length + " row(s) imported from Excel.";
          if (result.skipped > 0) {
            sMsg += "\n" + result.skipped + " row(s) skipped (empty).";
          }
          MessageToast.show(sMsg);
        },

        // ── onInit ───────────────────────────────────────────────────────
        onInit: function () {
          this._aMainRows = [];
          this._aFieldDef = [];

          this.getView().setModel(new JSONModel({ rows: [] }), "tableData");

          const oUIModel = new JSONModel({
            editMode:       true,
            requestCreated: false,
            viewOnly:       false,
            mainLoadFailed: false,
            rowStats:       "",
          });
          this.getView().setModel(oUIModel, "ui");

          const oFilterModel = new JSONModel({
            EnvId: "", BranchId: "", CustGroup: "", Currency: "", Search: "",
          });
          this.getView().setModel(oFilterModel, "filter");

          const oRequestContext = this._getUrlParams();
          this.getView().setModel(new JSONModel(oRequestContext), "requestContext");

          const bHasReqId = !!oRequestContext.ReqId;
          const sStatus   = oRequestContext.Status || (bHasReqId ? "Draft" : "Not Created");

          this.getView().setModel(new JSONModel({
            ReqId:       oRequestContext.ReqId || "",
            ReqItemId:   "",
            ConfId:      oRequestContext.ConfId || "",
            ReqTitle:    "",
            Status:      sStatus,
            StatusState: bHasReqId ? "Information" : "None",
            Reason:      "",
          }), "request");

          if (oRequestContext.ConfId) {
            this._fetchFieldDef(oRequestContext.ConfId);
          }

          if (bHasReqId) {
            const bIsDraft = sStatus.toUpperCase() === "DRAFT";
            oUIModel.setProperty("/requestCreated", true);
            oUIModel.setProperty("/editMode", bIsDraft);
            oUIModel.setProperty("/viewOnly", !bIsDraft);
            this._fetchRequestHeader(oRequestContext.ReqId);
            this._fetchReqItem(oRequestContext.ReqId);
            this._loadMainTableWithOverlay(
              oRequestContext.EnvId,
              oRequestContext.ReqId
            );
          } else if (oRequestContext.Mode === "VIEW") {
            oUIModel.setProperty("/editMode",  false);
            oUIModel.setProperty("/viewOnly",  true);
            this._loadMainTable(oRequestContext.EnvId || "DEV");
          }

          console.log("[SDPrice] requestContext =", oRequestContext);
        },

        // ── onCancel ─────────────────────────────────────────────────────
        onCancel: async function () {
          const oView  = this.getView();
          const sReqId = oView.getModel("request").getProperty("/ReqId");
          const sEnvId =
            oView.getModel("requestContext").getProperty("/EnvId") || "DEV";

          oView.setBusy(true);
          try {
            if (sReqId) {
              await this._loadMainTableWithOverlay(sEnvId, sReqId);
            } else {
              oView
                .getModel("tableData")
                .setProperty("/rows", this._aMainRows.map(r => ({ ...r })));
            }
            this._applyBaseFilter();
          } finally {
            oView.setBusy(false);
          }
          oView.getModel("ui").setProperty("/editMode", false);
          MessageToast.show("Changes cancelled");
        },

        // ── onCreate ─────────────────────────────────────────────────────
        onCreate: function () {
          const sReqId = this.getView().getModel("request").getProperty("/ReqId");
          if (!sReqId) {
            MessageBox.warning(
              "Please create a request first before adding price lines."
            );
            return;
          }

          const sEnvId =
            this.getView().getModel("requestContext").getProperty("/EnvId") ||
            "DEV";
          const oTableModel = this.getView().getModel("tableData");
          const aRows = oTableModel.getProperty("/rows");

          aRows.unshift({
            ItemId:      "",
            EnvId:       sEnvId,
            BranchId:    "",
            CustGroup:   "",
            MaterialGrp: "",
            MaxDiscount: 0,
            MinOrderVal: 0,
            ApproverGrp: "",
            Currency:    "",
            ValidFrom:   null,
            ValidTo:     null,
            VersionNo:   0,
            ChangeNote:  "",
            ActionType:  "C",
            _state:      "new",
            _reqItemId:  null,
          });

          oTableModel.setProperty("/rows", aRows);
          this._applyBaseFilter();
          MessageToast.show("New row added — fill in the fields and save.");
        },

        // ── onDelete ─────────────────────────────────────────────────────
        onDelete: function () {
          const oTable   = this.byId("priceTable");
          const aIndices = oTable.getSelectedIndices();
          if (!aIndices.length) {
            MessageToast.show("Select row(s) to delete");
            return;
          }

          MessageBox.confirm("Delete selected row(s)?", {
            onClose: (sAction) => {
              if (sAction !== "OK") return;

              const oTableModel = this.getView().getModel("tableData");
              const aRows = oTableModel.getProperty("/rows");

              // Reverse order so splice doesn't shift subsequent indices
              [...aIndices].sort((a, b) => b - a).forEach(iIdx => {
                const oRow = aRows[iIdx];
                if (!oRow) return;
                if (oRow._state === "new") {
                  aRows.splice(iIdx, 1);
                } else {
                  aRows[iIdx]._state     = "deleted";
                  aRows[iIdx].ActionType = "X";
                }
              });

              oTable.clearSelection();
              oTableModel.setProperty("/rows", aRows);
              this._applyBaseFilter();
              MessageToast.show("Marked for deletion — save to confirm.");
            },
          });
        },

        // ── onSave ───────────────────────────────────────────────────────
        onSave: async function () {
          const oView         = this.getView();
          const oRequestModel = oView.getModel("request");
          const sReqId        = oRequestModel.getProperty("/ReqId");
          const sTitle        = oRequestModel.getProperty("/ReqTitle") || "";
          const sReason       = oRequestModel.getProperty("/Reason")   || "";

          const oTableModelV = oView.getModel("tableData");
          const aAllRows     = oTableModelV.getProperty("/rows");
          const aErrors      = this._validateRows(aAllRows);
          oTableModelV.setProperty("/rows", aAllRows);

          if (aErrors.length > 0) {
            MessageBox.error(
              "Please fix the following errors before saving:\n\n" +
                aErrors.join("\n"),
              { title: "Validation Error" }
            );
            return;
          }

          oView.setBusy(true);
          try {
            const sCsrfToken = await this._fetchCsrfToken(
              this._getServiceUrl() + "?sap-client=" + this._getSapClient()
            );
            if (!sCsrfToken) throw new Error("Cannot fetch CSRF token");

            const aRows      = oView.getModel("tableData").getProperty("/rows");
            const sReqItemId = oRequestModel.getProperty("/ReqItemId") || "";
            const sConfId    = oRequestModel.getProperty("/ConfId")    || "";

            if (!sReqItemId) {
              oView.setBusy(false);
              MessageBox.error(
                "Cannot save: Request item data could not be loaded. Please refresh and try again."
              );
              return;
            }

            const mOrig = {};
            this._aMainRows.forEach(r => { mOrig[r.ItemId] = r; });

            let iSaved = 0;

            for (const row of aRows) {

              // ── NEW row ──────────────────────────────────────────────
              if (row._state === "new") {
                const oCreated = await this._postAndActivateReqRow({
                  ReqId:       sReqId,
                  ReqItemId:   sReqItemId,
                  ActionType:  "C",
                  EnvId:       row.EnvId       || "",
                  BranchId:    row.BranchId    || "",
                  CustGroup:   row.CustGroup   || "",
                  MaterialGrp: row.MaterialGrp || "",
                  MaxDiscount: parseFloat(row.MaxDiscount || 0),
                  MinOrderVal: parseInt(row.MinOrderVal || 0, 10),
                  ApproverGrp: row.ApproverGrp || "",
                  Currency:    row.Currency    || "",
                  ValidFrom:   row.ValidFrom   || null,
                  ValidTo:     row.ValidTo     || null,
                  VersionNo:   0,
                  ChangeNote:  row.ChangeNote  || "",
                }, sCsrfToken);

                if (oCreated?.ItemId) {
                  row._reqItemId = {
                    ReqId:     oCreated.ReqId,
                    ReqItemId: oCreated.ReqItemId,
                    ItemId:    oCreated.ItemId,
                  };
                  iSaved++;
                }
                continue;
              }

              // ── DELETED row ──────────────────────────────────────────
              if (row._state === "deleted") {
                const orig = mOrig[row.ItemId] || row;
                if (!row._reqItemId) {
                  await this._postAndActivateReqRow({
                    ReqId:        sReqId,
                    ReqItemId:    sReqItemId,
                    ActionType:   "X",
                    SourceItemId: row.ItemId,
                    EnvId:        row.EnvId       || "",
                    BranchId:     row.BranchId    || "",
                    CustGroup:    row.CustGroup   || "",
                    MaterialGrp:  row.MaterialGrp || "",
                    MaxDiscount:  parseFloat(row.MaxDiscount || 0),
                    MinOrderVal:  parseInt(row.MinOrderVal || 0, 10),
                    ApproverGrp:  row.ApproverGrp || "",
                    Currency:     row.Currency    || "",
                    ValidFrom:    row.ValidFrom   || null,
                    ValidTo:      row.ValidTo     || null,
                    VersionNo:    row.VersionNo   || 0,
                    ChangeNote:   row.ChangeNote  || "",
                  }, sCsrfToken);
                  iSaved++;
                } else {
                  await this._editPatchActivateReqRow(
                    row._reqItemId,
                    { ActionType: "X" },
                    sCsrfToken
                  );
                  iSaved++;
                }
                continue;
              }

              // ── MODIFIED main row ────────────────────────────────────
              if (!row.ItemId) continue;
              const orig = mOrig[row.ItemId];
              if (!orig) continue;

              const bChanged =
                (row.BranchId    || "") !== (orig.BranchId    || "") ||
                (row.CustGroup   || "") !== (orig.CustGroup   || "") ||
                (row.MaterialGrp || "") !== (orig.MaterialGrp || "") ||
                parseFloat(row.MaxDiscount || 0) !== parseFloat(orig.MaxDiscount || 0) ||
                parseInt(row.MinOrderVal   || 0, 10) !== parseInt(orig.MinOrderVal   || 0, 10) ||
                (row.ApproverGrp || "") !== (orig.ApproverGrp || "") ||
                (row.Currency    || "") !== (orig.Currency    || "") ||
                (row.ValidFrom   || "") !== (orig.ValidFrom   || "") ||
                (row.ValidTo     || "") !== (orig.ValidTo     || "") ||
                !!(row.ChangeNote || "").trim();

              if (!bChanged) continue;

              if (!row._reqItemId) {
                const oCreated = await this._postAndActivateReqRow({
                  ReqId:        sReqId,
                  ReqItemId:    sReqItemId,
                  ActionType:   "U",
                  SourceItemId: row.ItemId,
                  EnvId:        row.EnvId       || "",
                  BranchId:     row.BranchId    || "",
                  CustGroup:    row.CustGroup   || "",
                  MaterialGrp:  row.MaterialGrp || "",
                  MaxDiscount:  parseFloat(row.MaxDiscount || 0),
                  MinOrderVal:  parseInt(row.MinOrderVal || 0, 10),
                  ApproverGrp:  row.ApproverGrp || "",
                  Currency:     row.Currency    || "",
                  ValidFrom:    row.ValidFrom   || null,
                  ValidTo:      row.ValidTo     || null,
                  VersionNo:    orig.VersionNo  || 0,
                  ChangeNote:   row.ChangeNote  || "",
                }, sCsrfToken);

                if (oCreated?.ItemId) {
                  row._state     = "modified";
                  row._reqItemId = {
                    ReqId:     oCreated.ReqId,
                    ReqItemId: oCreated.ReqItemId,
                    ItemId:    oCreated.ItemId,
                  };
                  row.ActionType = "U";
                  iSaved++;
                }
              } else {
                await this._editPatchActivateReqRow(
                  row._reqItemId,
                  {
                    BranchId:    row.BranchId    || "",
                    CustGroup:   row.CustGroup   || "",
                    MaterialGrp: row.MaterialGrp || "",
                    MaxDiscount: parseFloat(row.MaxDiscount || 0),
                    MinOrderVal: parseInt(row.MinOrderVal || 0, 10),
                    ApproverGrp: row.ApproverGrp || "",
                    Currency:    row.Currency    || "",
                    ValidFrom:   row.ValidFrom   || null,
                    ValidTo:     row.ValidTo     || null,
                    ChangeNote:  row.ChangeNote  || "",
                  },
                  sCsrfToken
                );
                iSaved++;
              }
            }

            oView.getModel("tableData").setProperty("/rows", aRows);
            if (sReqId) await this._patchRequestHeader(sReqId, sTitle, sReason);

            oView.getModel("ui").setProperty("/editMode", false);
            this._applyBaseFilter();
            MessageToast.show(
              iSaved > 0
                ? iSaved + " change(s) saved to request."
                : "No changes detected."
            );
          } catch (e) {
            console.error(e);
            MessageBox.error(e?.message || "Save failed");
          } finally {
            oView.setBusy(false);
          }
        },

        // ── onRefresh ────────────────────────────────────────────────────
        onRefresh: async function () {
          const sReqId =
            this.getView().getModel("request").getProperty("/ReqId");
          const sEnvId =
            this.getView().getModel("requestContext").getProperty("/EnvId") ||
            "DEV";
          this.getView().setBusy(true);
          try {
            if (sReqId) {
              await this._loadMainTableWithOverlay(sEnvId, sReqId);
            } else {
              await this._loadMainTable(sEnvId);
            }
            this._applyBaseFilter();
            MessageToast.show("Refreshed");
          } catch (e) {
            MessageBox.error("Refresh failed");
          } finally {
            this.getView().setBusy(false);
          }
        },

        // ── onSearch ─────────────────────────────────────────────────────
        onSearch: function () {
          const oTable      = this.byId("priceTable");
          const oBinding    = oTable.getBinding("rows");
          const oFilterData = this.getView().getModel("filter").getData();

          const aFilters = [];

          if (oFilterData.EnvId)
            aFilters.push(new Filter("EnvId",    FilterOperator.Contains, oFilterData.EnvId));
          if (oFilterData.BranchId)
            aFilters.push(new Filter("BranchId", FilterOperator.Contains, oFilterData.BranchId));
          if (oFilterData.CustGroup)
            aFilters.push(new Filter("CustGroup", FilterOperator.Contains, oFilterData.CustGroup));
          if (oFilterData.Currency)
            aFilters.push(new Filter("Currency", FilterOperator.Contains, oFilterData.Currency));

          const sSearch = this.byId("searchField").getValue();
          if (sSearch) {
            aFilters.push(new Filter({
              filters: [
                new Filter("EnvId",       FilterOperator.Contains, sSearch),
                new Filter("BranchId",    FilterOperator.Contains, sSearch),
                new Filter("CustGroup",   FilterOperator.Contains, sSearch),
                new Filter("MaterialGrp", FilterOperator.Contains, sSearch),
                new Filter("ApproverGrp", FilterOperator.Contains, sSearch),
                new Filter("Currency",    FilterOperator.Contains, sSearch),
              ],
              and: false,
            }));
          }

          oBinding.filter(aFilters);
        },

        // ── onClearFilters ───────────────────────────────────────────────
        onClearFilters: function () {
          this.getView().getModel("filter").setData({
            EnvId: "", BranchId: "", CustGroup: "", Currency: "", Search: "",
          });
          this.byId("searchField").setValue("");
          this._applyBaseFilter();
          MessageToast.show("Filters cleared");
        },

        // ── Value help: helper to write back to the row that opened the dialog ──
        _setCellValue: function (sValue) {
          if (!this._oCellCtx) return;
          this._oCellCtx.getModel().setProperty(
            this._oCellCtx.getPath() + "/" + this._sCellField,
            sValue
          );
        },

        // ── Value help: Branch (cell) ────────────────────────────────────
        onValueHelpBranchCell: function (oEvent) {
          this._oCellCtx   = oEvent.getSource().getBindingContext("tableData");
          this._sCellField = "BranchId";
          if (!this._oBranchCellDialog) {
            this._oBranchCellDialog = new SelectDialog({
              title: "Select Branch",
              liveChange: function (oEv) {
                const sVal = oEv.getParameter("value");
                oEv.getSource().getBinding("items").filter([
                  new Filter("BranchId", FilterOperator.Contains, sVal),
                ]);
              },
              search: function (oEv) {
                const sVal = oEv.getParameter("value");
                oEv.getSource().getBinding("items").filter([
                  new Filter("BranchId", FilterOperator.Contains, sVal),
                ]);
              },
              confirm: (oEv) => {
                const oItem = oEv.getParameter("selectedItem");
                if (oItem) this._setCellValue(oItem.getTitle());
              },
            });
            this._oBranchCellDialog.bindAggregation("items", {
              path: "/BranchDef",
              template: new StandardListItem({ title: "{BranchId}", description: "{Description}" }),
            });
            this.getView().addDependent(this._oBranchCellDialog);
          }
          this._oBranchCellDialog.open();
        },

        // ── Value help: Customer Group (cell) ────────────────────────────
        onValueHelpCustGroupCell: function (oEvent) {
          this._oCellCtx   = oEvent.getSource().getBindingContext("tableData");
          this._sCellField = "CustGroup";
          if (!this._oCustGroupCellDialog) {
            this._oCustGroupCellDialog = new SelectDialog({
              title: "Select Customer Group",
              liveChange: function (oEv) {
                const sVal = oEv.getParameter("value");
                oEv.getSource().getBinding("items").filter([
                  new Filter("CustGroup", FilterOperator.Contains, sVal),
                ]);
              },
              search: function (oEv) {
                const sVal = oEv.getParameter("value");
                oEv.getSource().getBinding("items").filter([
                  new Filter("CustGroup", FilterOperator.Contains, sVal),
                ]);
              },
              confirm: (oEv) => {
                const oItem = oEv.getParameter("selectedItem");
                if (oItem) this._setCellValue(oItem.getTitle());
              },
            });
            this._oCustGroupCellDialog.bindAggregation("items", {
              path: "/CustGroupDef",
              template: new StandardListItem({ title: "{CustGroup}", description: "{Description}" }),
            });
            this.getView().addDependent(this._oCustGroupCellDialog);
          }
          this._oCustGroupCellDialog.open();
        },

        // ── Value help: Currency (cell) ──────────────────────────────────
        onValueHelpCurrencyCell: function (oEvent) {
          this._oCellCtx   = oEvent.getSource().getBindingContext("tableData");
          this._sCellField = "Currency";
          if (!this._oCurrencyCellDialog) {
            this._oCurrencyCellDialog = new SelectDialog({
              title: "Select Currency",
              liveChange: function (oEv) {
                const sVal = oEv.getParameter("value");
                oEv.getSource().getBinding("items").filter([
                  new Filter("Currency", FilterOperator.Contains, sVal),
                ]);
              },
              search: function (oEv) {
                const sVal = oEv.getParameter("value");
                oEv.getSource().getBinding("items").filter([
                  new Filter("Currency", FilterOperator.Contains, sVal),
                ]);
              },
              confirm: (oEv) => {
                const oItem = oEv.getParameter("selectedItem");
                if (oItem) this._setCellValue(oItem.getTitle());
              },
            });
            this._oCurrencyCellDialog.bindAggregation("items", {
              path: "/CurrencyDef",
              template: new StandardListItem({ title: "{Currency}", description: "{CurrencyName}" }),
            });
            this.getView().addDependent(this._oCurrencyCellDialog);
          }
          this._oCurrencyCellDialog.open();
        },

        // ── Value help: Material Group (cell) ────────────────────────────
        onValueHelpMaterialGrpCell: function (oEvent) {
          this._oCellCtx   = oEvent.getSource().getBindingContext("tableData");
          this._sCellField = "MaterialGrp";
          if (!this._oMatlGrpCellDialog) {
            this._oMatlGrpCellDialog = new SelectDialog({
              title: "Select Material Group",
              liveChange: function (oEv) {
                const sVal = oEv.getParameter("value");
                oEv.getSource().getBinding("items").filter([
                  new Filter("MatlGrp", FilterOperator.Contains, sVal),
                ]);
              },
              search: function (oEv) {
                const sVal = oEv.getParameter("value");
                oEv.getSource().getBinding("items").filter([
                  new Filter("MatlGrp", FilterOperator.Contains, sVal),
                ]);
              },
              confirm: (oEv) => {
                const oItem = oEv.getParameter("selectedItem");
                if (oItem) this._setCellValue(oItem.getTitle());
              },
            });
            this._oMatlGrpCellDialog.bindAggregation("items", {
              path: "/MatlGrpDef",
              template: new StandardListItem({ title: "{MatlGrp}", description: "{Description}" }),
            });
            this.getView().addDependent(this._oMatlGrpCellDialog);
          }
          this._oMatlGrpCellDialog.open();
        },

        // ── Value help: Approver (cell) ──────────────────────────────────
        onValueHelpApproverCell: function (oEvent) {
          this._oCellCtx   = oEvent.getSource().getBindingContext("tableData");
          this._sCellField = "ApproverGrp";
          if (!this._oApproverCellDialog) {
            this._oApproverCellDialog = new SelectDialog({
              title: "Select Approver",
              liveChange: function (oEv) {
                const sVal = oEv.getParameter("value");
                oEv.getSource().getBinding("items").filter([
                  new Filter("UserId", FilterOperator.Contains, sVal),
                ]);
              },
              search: function (oEv) {
                const sVal = oEv.getParameter("value");
                oEv.getSource().getBinding("items").filter([
                  new Filter("UserId", FilterOperator.Contains, sVal),
                ]);
              },
              confirm: (oEv) => {
                const oItem = oEv.getParameter("selectedItem");
                if (oItem) this._setCellValue(oItem.getTitle());
              },
            });
            this._oApproverCellDialog.bindAggregation("items", {
              path: "/InspectorDef",
              template: new StandardListItem({ title: "{UserId}", description: "{Fullname} ({RoleLevel})" }),
            });
            this.getView().addDependent(this._oApproverCellDialog);
          }
          this._oApproverCellDialog.open();
        },

        // ── Private: service URL ─────────────────────────────────────────
        _getServiceUrl: function () {
          return "/sap/opu/odata4/sap/zsd_sd_price_conf/srvd/sap/zsd_sd_price_conf/0001/";
        },

        // ── Private: validate rows before save ───────────────────────────
        _validateRows: function (aRows) {
          const aErrors   = [];
          const aFieldDef = this._aFieldDef || [];

          const aRequired = aFieldDef.length > 0
            ? aFieldDef.filter(function (f) { return f.IsRequired; })
            : [
                { FieldName: "BRANCH_ID",  FieldLabel: "Branch" },
                { FieldName: "CUST_GROUP", FieldLabel: "Customer Group" },
                { FieldName: "CURRENCY",   FieldLabel: "Currency" },
                { FieldName: "VALID_FROM", FieldLabel: "Valid From" },
                { FieldName: "VALID_TO",   FieldLabel: "Valid To" },
              ];

          aRows.forEach(function (row, iIdx) {
            Object.keys(row).forEach(function (k) {
              if (k.startsWith("_vs_")) row[k] = "None";
            });

            if (row._state === "deleted") return;

            const sRowNum = "Row " + (iIdx + 1);

            // Required fields
            aRequired.forEach(function (fieldDef) {
              const sJsKey = this._dbToPascal(fieldDef.FieldName);
              const sVsKey = "_vs_" + sJsKey;
              const sVal   = String(row[sJsKey] ?? "").trim();
              if (!sVal) {
                row[sVsKey] = "Error";
                aErrors.push(sRowNum + ": " + fieldDef.FieldLabel + " is required.");
              }
            }.bind(this));

            // ValidFrom ≤ ValidTo
            const sFrom = String(row.ValidFrom ?? "").trim();
            const sTo   = String(row.ValidTo   ?? "").trim();
            if (sFrom && sTo && sFrom > sTo) {
              row._vs_ValidFrom = "Error";
              row._vs_ValidTo   = "Error";
              aErrors.push(sRowNum + ": Valid From must be on or before Valid To.");
            }

            // MaxDiscount ≥ 0
            const nDisc = parseFloat(row.MaxDiscount);
            if (!isNaN(nDisc) && nDisc < 0) {
              row._vs_MaxDiscount = "Error";
              aErrors.push(sRowNum + ": Max Discount must be 0 or greater.");
            }

            // MinOrderVal ≥ 0
            const nMin = parseFloat(row.MinOrderVal);
            if (!isNaN(nMin) && nMin < 0) {
              row._vs_MinOrderVal = "Error";
              aErrors.push(sRowNum + ": Min Order Value must be 0 or greater.");
            }
          }.bind(this));

          return aErrors;
        },

        // ── Private: load main config table ──────────────────────────────
        _loadMainTable: async function (sEnvId) {
          const sUrl =
            this._getServiceUrl() +
            "SDPriceMain?$filter=EnvId eq '" + sEnvId + "'&$orderby=BranchId,CustGroup" +
            "&sap-client=" + this._getSapClient();

          const oResp = await fetch(sUrl, {
            headers: {
              Accept: "application/json",
              "X-Requested-With": "XMLHttpRequest",
            },
            credentials: "include",
          });

          if (!oResp.ok) {
            console.error("[SDPrice] SDPriceMain load failed:", oResp.status, oResp.statusText);
            this.getView().getModel("ui").setProperty("/mainLoadFailed", true);
            this.getView().getModel("tableData").setProperty("/rows", []);
            return;
          }

          this.getView().getModel("ui").setProperty("/mainLoadFailed", false);
          const aRaw  = (await oResp.json()).value || [];
          const aRows = aRaw.map(r => ({
            ...r,
            ActionType: "",
            ChangeNote: "",
            _state:     "unchanged",
            _reqItemId: null,
          }));

          this._aMainRows = aRows.map(r => ({ ...r }));
          this.getView().getModel("tableData").setProperty("/rows", aRows);
          this._updateRowStats();
        },

        // ── Private: load main table + overlay with request rows ──────────
        _loadMainTableWithOverlay: async function (sEnvId, sReqId) {
          const sBase      = this._getServiceUrl();
          const sSapClient = this._getSapClient();

          const [oMainResp, oReqResp] = await Promise.all([
            fetch(
              sBase + "SDPriceMain?$filter=EnvId eq '" + sEnvId +
              "'&$orderby=BranchId,CustGroup&sap-client=" + sSapClient,
              {
                headers: {
                  Accept: "application/json",
                  "X-Requested-With": "XMLHttpRequest",
                },
                credentials: "include",
              }
            ),
            fetch(
              sBase + "SDPriceConf?$filter=ReqId eq " + sReqId +
              "&$select=ItemId,ReqId,ReqItemId,SourceItemId,ActionType,EnvId," +
              "BranchId,CustGroup,MaterialGrp,MaxDiscount,MinOrderVal," +
              "ApproverGrp,Currency,ValidFrom,ValidTo,VersionNo,ChangeNote" +
              "&sap-client=" + sSapClient,
              {
                headers: {
                  Accept: "application/json",
                  "X-Requested-With": "XMLHttpRequest",
                },
                credentials: "include",
              }
            ),
          ]);

          // Show warning if main config data could not be fetched
          if (!oMainResp.ok) {
            console.error(
              "[SDPrice] SDPriceMain fetch failed:",
              oMainResp.status, oMainResp.statusText,
              "→ Ensure entity 'SDPriceMain' (view ZC_SD_PRICE_MAIN) exists in service binding ZSD_SD_PRICE_CONF"
            );
            this.getView().getModel("ui").setProperty("/mainLoadFailed", true);
          } else {
            this.getView().getModel("ui").setProperty("/mainLoadFailed", false);
          }

          const aMain = oMainResp.ok ? ((await oMainResp.json()).value || []) : [];
          const aReq  = oReqResp.ok  ? ((await oReqResp.json()).value  || []) : [];

          // ABAP returns "00000000-0000-0000-0000-000000000000" for initial UUID fields,
          // not null. Treat that as "no source" (i.e. a CREATE row).
          const isBlankId = id => !id || id === "00000000-0000-0000-0000-000000000000";

          // Map: SourceItemId → req row (for U and X rows only)
          const mReq = {};
          aReq.forEach(r => { if (!isBlankId(r.SourceItemId)) mReq[r.SourceItemId] = r; });

          // Merge: main rows overlaid with any saved delta
          const aRows = aMain.map(mainRow => {
            const req = mReq[mainRow.ItemId];
            if (req) {
              return {
                ...req,
                _state:     req.ActionType === "X" ? "deleted" : "modified",
                _reqItemId: {
                  ReqId:     req.ReqId,
                  ReqItemId: req.ReqItemId,
                  ItemId:    req.ItemId,
                },
              };
            }
            return {
              ...mainRow,
              ActionType: "",
              ChangeNote: "",
              _state:     "unchanged",
              _reqItemId: null,
            };
          });

          // Append CREATE-only req rows (SourceItemId blank or all-zeros)
          aReq.filter(r => isBlankId(r.SourceItemId)).forEach(r => {
            aRows.push({
              ...r,
              _state:     "new",
              _reqItemId: { ReqId: r.ReqId, ReqItemId: r.ReqItemId, ItemId: r.ItemId },
            });
          });

          // Append DELETE req rows whose source no longer exists in main table
          // (happens after approval: the row was deleted from SDPriceMain but
          //  the request history (SDPriceConf) still holds the X record)
          const mMainIds = {};
          aMain.forEach(r => { mMainIds[r.ItemId] = true; });
          aReq.filter(r => r.ActionType === "X" && !isBlankId(r.SourceItemId) && !mMainIds[r.SourceItemId]).forEach(r => {
            aRows.push({
              ...r,
              _state:     "deleted",
              _reqItemId: { ReqId: r.ReqId, ReqItemId: r.ReqItemId, ItemId: r.ItemId },
            });
          });

          this._aMainRows = aMain.map(r => ({ ...r }));
          this.getView().getModel("tableData").setProperty("/rows", aRows);
          this._updateRowStats();
        },

        // ── Private: POST → Activate req row ────────────────────────────
        _postAndActivateReqRow: async function (oPayload, sCsrfToken) {
          const sBase      = this._getServiceUrl();
          const sSapClient = this._getSapClient();
          const sNs        = "com.sap.gateway.srvd.zsd_sd_price_conf.v0001";
          const oHeaders   = {
            "Content-Type":    "application/json",
            "X-CSRF-Token":    sCsrfToken,
            "X-Requested-With":"XMLHttpRequest",
            Accept:            "application/json",
          };

          const oPostResp = await fetch(
            sBase + "SDPriceConf?sap-client=" + sSapClient,
            { method: "POST", headers: oHeaders, credentials: "include", body: JSON.stringify(oPayload) }
          );
          if (!oPostResp.ok) {
            const sRaw = await oPostResp.text().catch(() => "");
            let sMsg = "POST SDPriceConf failed (" + oPostResp.status + ")";
            try { sMsg = JSON.parse(sRaw)?.error?.message || sMsg; } catch (_) {}
            console.error("[SDPrice] POST failed — raw response:", sRaw);
            throw new Error(sMsg);
          }
          const oDraft = await oPostResp.json();

          const sDraftKey =
            "ReqId=" + oDraft.ReqId +
            ",ReqItemId=" + oDraft.ReqItemId +
            ",ItemId=" + oDraft.ItemId;

          const oActResp = await fetch(
            sBase + "SDPriceConf(" + sDraftKey + ",IsActiveEntity=false)/" +
            sNs + ".Activate?sap-client=" + sSapClient,
            { method: "POST", headers: oHeaders, credentials: "include", body: JSON.stringify({}) }
          );
          if (!oActResp.ok) {
            const oActErr = await oActResp.json().catch(() => ({}));
            throw new Error(
              this._extractODataError(oActErr) || "Activate failed (" + oActResp.status + ")"
            );
          }
          return oActResp.json();
        },

        // ── Private: Edit → PATCH → Activate req row ─────────────────────
        _editPatchActivateReqRow: async function (oKeys, oPayload, sCsrfToken) {
          const sBase      = this._getServiceUrl();
          const sSapClient = this._getSapClient();
          const sNs        = "com.sap.gateway.srvd.zsd_sd_price_conf.v0001";
          const oHeaders   = {
            "Content-Type":    "application/json",
            "X-CSRF-Token":    sCsrfToken,
            "X-Requested-With":"XMLHttpRequest",
            Accept:            "application/json",
          };

          const sActiveKey =
            "ReqId=" + oKeys.ReqId +
            ",ReqItemId=" + oKeys.ReqItemId +
            ",ItemId=" + oKeys.ItemId;

          const oEditResp = await fetch(
            sBase + "SDPriceConf(" + sActiveKey + ",IsActiveEntity=true)/" +
            sNs + ".Edit?sap-client=" + sSapClient,
            { method: "POST", headers: oHeaders, credentials: "include", body: JSON.stringify({ PreserveChanges: false }) }
          );
          if (!oEditResp.ok) {
            const oErr = await oEditResp.json().catch(() => ({}));
            throw new Error(oErr?.error?.message || "Edit action failed (" + oEditResp.status + ")");
          }
          const oDraft = await oEditResp.json();

          const sDraftKey =
            "ReqId=" + (oDraft.ReqId || oKeys.ReqId) +
            ",ReqItemId=" + (oDraft.ReqItemId || oKeys.ReqItemId) +
            ",ItemId=" + (oDraft.ItemId || oKeys.ItemId);

          const oPatchResp = await fetch(
            sBase + "SDPriceConf(" + sDraftKey + ",IsActiveEntity=false)?sap-client=" + sSapClient,
            { method: "PATCH", headers: oHeaders, credentials: "include", body: JSON.stringify(oPayload) }
          );
          if (!oPatchResp.ok) {
            const oErr = await oPatchResp.json().catch(() => ({}));
            throw new Error(oErr?.error?.message || "PATCH draft failed (" + oPatchResp.status + ")");
          }

          const oActResp = await fetch(
            sBase + "SDPriceConf(" + sDraftKey + ",IsActiveEntity=false)/" +
            sNs + ".Activate?sap-client=" + sSapClient,
            { method: "POST", headers: oHeaders, credentials: "include", body: JSON.stringify({}) }
          );
          if (!oActResp.ok) {
            const oErr = await oActResp.json().catch(() => ({}));
            throw new Error(
              this._extractODataError(oErr) || "Activate failed (" + oActResp.status + ")"
            );
          }
        },

        // ── Private: compute and display row stats in toolbar ────────────
        _updateRowStats: function () {
          const aRows    = this.getView().getModel("tableData").getProperty("/rows") || [];
          const iVisible  = aRows.filter(r => r._state !== "deleted").length;
          const iNew      = aRows.filter(r => r._state === "new").length;
          const iModified = aRows.filter(r => r._state === "modified").length;
          const iDeleted  = aRows.filter(r => r._state === "deleted").length;

          const aParts = [iVisible + " line" + (iVisible !== 1 ? "s" : "")];
          if (iNew)      aParts.push(iNew + " new");
          if (iModified) aParts.push(iModified + " modified");
          if (iDeleted)  aParts.push(iDeleted + " to delete");

          this.getView().getModel("ui").setProperty("/rowStats", aParts.join(" · "));
          this.byId("priceTable").setVisibleRowCount(Math.max(aRows.length, 1));
        },

        // ── Private: refresh table binding (show all rows incl. deleted) ────
        _applyBaseFilter: function () {
          const oBinding = this.byId("priceTable").getBinding("rows");
          if (oBinding) oBinding.filter([]);
          this._updateRowStats();
        },
      }
    );
  }
);
