sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("zgsp26.conf.mng.sdprice.confmngfesdprice.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);
